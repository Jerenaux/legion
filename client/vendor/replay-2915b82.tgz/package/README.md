# Replay backend and dashboard

Game-agnostic backend and dashboard for the Godot
[`Replay` addon](https://github.com/Jerenaux/autobattler/tree/main/addons/replay). Deployed in Firebase project `games-analytics-jr` (europe-west1).

- `replayIngest` (public, write-only): accepts RPLY segments for games listed in
  `REPLAY_GAMES`, validates and stores them immutably in
  `gs://games-analytics-jr-replays/{game}/{session}/{seq}.rply`, and updates the
  Firestore summary `replaySessions/{session}` (metadata, duration, frames, size,
  errors, event marks, country). Country comes from the uploader's IP via DB-IP's
  free country database (CC BY 4.0, https://db-ip.com); the IP is not stored.
- `replayApi` (private): session list, session, segment bytes and deletion for the
  dashboard. Requires a Firebase ID token for an email in `REPLAY_ADMINS`. Deleting
  writes a tombstone (`replayTombstones/{session}`), so segments still waiting in a
  player's outbox are refused with 410 instead of recreating the session.
- `dashboard/`: static site at https://games-replay-jr.web.app, `/api/**` rewritten
  to `replayApi`. It can also play `.rply` files from disk (drop them on the page),
  including when served locally without a backend.

Retention: the bucket deletes objects after 90 days; a Firestore TTL policy on
`expireAt` removes session documents and tombstones. Functions run as the dedicated
`replay-runtime` service account (bucket object admin + Firestore user).

## Deploy

```sh
cd ~/Code/replay
npm ci --prefix functions
npm --prefix functions run build-geo # compiles the country database
firebase deploy --only functions:replay,hosting:games-replay-jr
```

The `replay` codebase never touches the analytics functions. Configuration is in
`functions/.env` (bucket, games, admins, retention).

## Dashboard sign-in (one-time)

In the Firebase console for `games-analytics-jr`: Authentication > Get started >
Sign-in method > enable **Google**; then Authentication > Settings > Authorized
domains > add `games-replay-jr.web.app`.

## Electron library

The dependency-free `@jerenaux/replay` package in this repository records the composed
Electron window (including DOM overlays and WebGL) in the same RPLY v1 format as Godot.
Install from a pinned Git commit. The host application owns recording eligibility.

```js
// Main process, after creating the window:
const {installReplay} = require('@jerenaux/replay/electron');
const recorder = installReplay(window, {
  game: 'legion',
  endpoint: 'https://europe-west1-games-analytics-jr.cloudfunctions.net/replayIngest',
  outbox: path.join(app.getPath('userData'), 'replay', 'outbox'),
  isTrustedURL: url => url.startsWith('app://legion/'),
  metadata: {game_version: app.getVersion(), channel: 'local'},
});
// Await recorder.stop() before destroying the window, with a bounded quit deadline.
```

In a sandboxed preload, expose only these fixed IPC methods through `contextBridge`:
`start`, `capture`, `frame`, `event`, `identify`, `flush`, and `stop`, each invoking
`replay:<method>`. Import `startReplay` from `@jerenaux/replay/renderer` in the renderer
and pass that bridge. Start it once per document, before game initialization. Its
`event(name, data, style)` API accepts timeline labels/colors/highlights; `identify(id)`
starts a new session when the player identity changes. The main process verifies the
sender and URL for every call. Do not expose arbitrary IPC channel names to the page.

Capture is limited to 2 fps and 960 pixels wide, encoded to WebP at quality 0.5.
Identical thumbnails are skipped. Segments flush every 15 seconds or before 3.5 MB;
atomic disk writes precede uploads. The outbox retries after failures and on relaunch,
and drops its oldest files above 300 MB. A crash can lose the current in-memory segment.
Thirty minutes without input suspends a session; input resumes in a new session.
Capture gaps above two minutes split sessions as well.

Password inputs and elements with `data-replay-mask` or `data-private` are blanked in
frames. Text-field typing is never recorded as key events. Other visible text remains
visible, so mark sensitive UI before displaying it. Explicit event data is bounded and
scrubs credential fields and URL credentials/query/fragment. No network traffic or
console text is collected. Audio and browser-only page recording are not supported.
The recorder captures the app's page, never the desktop or other apps.

`npm test` runs dashboard checks. To include the real Electron capture/outbox/HTTP/
privacy compatibility check, set `REPLAY_ELECTRON` to an Electron executable before
running it. The integration check uses an isolated profile and loopback uploads only.
