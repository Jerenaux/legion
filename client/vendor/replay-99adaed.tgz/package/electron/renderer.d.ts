export interface ReplayBridge {
  start(): Promise<string>;
  capture(payload: {width: number; height: number; masks: number[][]}): Promise<null | {png: Uint8Array; width: number; height: number; time: number; session: string}>;
  frame(payload: unknown): Promise<void>;
  event(payload: unknown): Promise<void>;
  identify(player: string): Promise<string>;
  flush(): Promise<void>;
  stop(): Promise<void>;
}
export function startReplay(bridge?: ReplayBridge, onSession?: (id: string) => void, onError?: (error: Error, operation: string) => void): {
  event(name: string, data?: Record<string, unknown>, style?: {label?: string; color?: string; highlight?: string}): void;
  activity(): void;
  identify(player?: string): void;
  stop(): Promise<void> | void;
};
