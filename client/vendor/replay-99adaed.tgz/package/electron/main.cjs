const {ipcMain, nativeImage} = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
const {randomBytes, createHash} = require('node:crypto');
const {gzipSync} = require('node:zlib');

const recorders = new Map();
const MAX_BYTES = 3500 * 1024;
const IDLE_MS = 30 * 60000;
const id = () => randomBytes(16).toString('hex');

// Explicit game events are bounded and scrubbed too; never collect network traffic.
function clean(value, depth = 0) {
  if (depth > 3) return null;
  if (typeof value === 'string') {
    return value.replace(/https?:\/\/[^\s]+/g, text => {
      try { const url = new URL(text); url.username = url.password = url.search = url.hash = ''; return url.toString(); }
      catch { return '[URL]'; }
    }).slice(0, 256);
  }
  if (typeof value === 'boolean' || (typeof value === 'number' && Number.isFinite(value))) return value;
  if (Array.isArray(value)) return value.slice(0, 20).map(item => clean(item, depth + 1));
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).slice(0, 20)
    .filter(([key]) => !/pass|token|authorization|cookie|secret|email/i.test(key))
    .map(([key, item]) => [key.slice(0, 32), clean(item, depth + 1)]));
  return null;
}

for (const method of ['start', 'capture', 'frame', 'event', 'identify', 'flush', 'stop']) {
  ipcMain.handle('replay:' + method, (event, payload) => {
    const recorder = recorders.get(event.sender.id);
    if (!recorder || event.senderFrame !== event.sender.mainFrame
      || !recorder.options.isTrustedURL(event.senderFrame.url)) throw new Error('Untrusted replay sender');
    return Promise.resolve().then(() => recorder[method](payload)).catch(error => {
      recorder.warn(error, method);
      throw error;
    });
  });
}

class Recorder {
  constructor(window, options) {
    const endpoint = new URL(options.endpoint);
    if (endpoint.protocol !== 'https:' && !(endpoint.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(endpoint.hostname))) {
      throw new Error('Replay requires HTTPS or a loopback endpoint');
    }
    if (!/^[a-z0-9_-]{1,32}$/.test(options.game) || !path.isAbsolute(options.outbox)
      || typeof options.isTrustedURL !== 'function') throw new Error('Invalid replay configuration');
    this.window = window;
    this.contentsId = window.webContents.id;
    this.options = options;
    this.directory = options.outbox;
    this.pendingWrite = Promise.resolve();
    this.enabled = false;
    this.sequence = 0;
    this.metadata = {};
    this.reported = new Map();
    this.ready = fs.mkdir(this.directory, {recursive: true, mode: 0o700}).then(async () => {
      const file = path.join(this.directory, 'install-id');
      try { await fs.writeFile(file, id(), {flag: 'wx', mode: 0o600}); } catch (error) { if (error.code !== 'EEXIST') throw error; }
      this.installId = (await fs.readFile(file, 'utf8')).trim();
      for (const name of await fs.readdir(this.directory)) {
        if (/^[a-z0-9_-]+_[a-f0-9]{32}_\d{5}\.rply\.tmp$/.test(name)) await fs.unlink(path.join(this.directory, name));
      }
      await this.trim();
    });
    this.ready.catch(error => this.warn(error));
    this.retry = setInterval(() => { void this.flush().catch(error => this.warn(error)); }, 15000);
    this.retry.unref();
    recorders.set(window.webContents.id, this);
    window.once('closed', () => { void this.dispose().catch(error => this.warn(error)); });
  }

  warn(error, operation = 'recording') {
    const now = Date.now();
    if (now - (this.reported.get(operation) || 0) < 60000) return;
    this.reported.set(operation, now);
    // Never forward exception messages, paths, frame contents or server response bodies.
    const failure = new Error(`Replay ${operation} failed`);
    const code = String(error?.code || error?.name || 'Error');
    if (/^[\w-]{1,40}$/.test(code)) failure.code = code;
    console.warn(failure.message, failure.code || 'Error');
    try { this.options.onError?.(failure, operation); } catch { /* Diagnostics are optional. */ }
  }

  async start() {
    await this.ready;
    this.enabled = true;
    if (!this.session) this.begin();
    void this.upload();
    return this.session;
  }

  begin() {
    this.session = id();
    this.started = Date.now();
    this.lastInput = this.started;
    this.lastCapture = 0;
    this.sequence = 0;
    this.previous = null;
    this.reset();
  }

  reset() {
    this.segmentStart = Date.now() - this.started;
    this.events = [];
    this.frames = [];
    this.images = [];
    this.bytes = 0;
    this.eventBytes = 0;
    this.errors = 0;
    this.marks = new Set();
    this.highlights = new Set();
  }

  async capture(payload) {
    if (!this.enabled || this.capturing || this.window.isDestroyed() || this.window.isMinimized()) return null;
    const now = Date.now();
    if (now - this.lastCapture < 450) return null;
    if (this.session && (now - this.lastInput > IDLE_MS || (this.lastCapture && now - this.lastCapture > 120000))) {
      void this.write();
      this.session = null;
    }
    if (!this.session) return null;
    if (!payload || !Number.isFinite(payload.width) || !Number.isFinite(payload.height)
      || payload.width <= 0 || payload.height <= 0 || !Array.isArray(payload.masks) || payload.masks.length > 200) return null;
    this.lastCapture = now;
    this.capturing = true;
    const session = this.session;
    try {
      let image = await this.window.webContents.capturePage(undefined, {stayHidden: true, stayAwake: false});
      if (image.isEmpty() || this.session !== session || !this.enabled) return null;
      image = image.resize({width: Math.min(960, image.getSize().width)});
      const size = image.getSize();
      const pixels = image.toBitmap();
      for (const rect of payload.masks) {
        if (!Array.isArray(rect) || rect.length !== 4 || !rect.every(Number.isFinite)) return null;
        const left = Math.max(0, Math.floor(rect[0] / payload.width * size.width) - 2);
        const top = Math.max(0, Math.floor(rect[1] / payload.height * size.height) - 2);
        const right = Math.min(size.width, Math.ceil((rect[0] + rect[2]) / payload.width * size.width) + 2);
        const bottom = Math.min(size.height, Math.ceil((rect[1] + rect[3]) / payload.height * size.height) + 2);
        for (let y = top; y < bottom; y++) for (let x = left; x < right; x++) {
          const offset = (y * size.width + x) * 4;
          pixels[offset] = pixels[offset + 1] = pixels[offset + 2] = 16;
          pixels[offset + 3] = 255;
        }
      }
      image = nativeImage.createFromBitmap(pixels, size);
      const hash = createHash('sha256').update(image.resize({width: 64}).toBitmap()).digest('hex');
      if (hash === this.previous) return null;
      this.captured = {session, time: now - this.started, hash, width: size.width, height: size.height};
      return {png: image.toPNG(), width: size.width, height: size.height, time: now - this.started, session};
    } catch (error) { this.warn(error, 'capture'); return null; }
    finally { this.capturing = false; }
  }

  async frame(payload) {
    if (!this.enabled || !this.session || payload?.session !== this.session
      || payload.time !== this.captured?.time || payload.width !== this.captured.width || payload.height !== this.captured.height) return;
    const data = payload.bytes instanceof Uint8Array ? Buffer.from(payload.bytes) : null;
    if (!data || data.length > 2 * 1024 * 1024 || data.toString('ascii', 0, 4) !== 'RIFF'
      || data.toString('ascii', 8, 12) !== 'WEBP' || !Number.isFinite(payload.time)
      || payload.time < 0 || payload.time > Date.now() - this.started + 1000
      || !Number.isInteger(payload.width) || !Number.isInteger(payload.height)
      || payload.width < 1 || payload.width > 960 || payload.height < 1 || payload.height > 8192) return;
    if ((this.bytes + this.eventBytes + data.length > MAX_BYTES || this.size?.[0] !== payload.width || this.size?.[1] !== payload.height) && this.frames.length) await this.write();
    if (payload.session !== this.session || !this.enabled) return;
    this.size = [payload.width, payload.height];
    this.frames.push([payload.time, this.bytes, data.length]);
    this.previous = this.captured.hash;
    this.images.push(data);
    this.bytes += data.length;
    if (Date.now() - this.started - this.segmentStart >= 15000) await this.write();
  }

  async event(payload) {
    if (!this.enabled || !payload || typeof payload.type !== 'string') return;
    const input = ['m', 'c', 'w', 'k', 'f', 'v', 'a'].includes(payload.type);
    const now = Date.now();
    if (this.session && (now - this.lastInput > IDLE_MS || (this.lastCapture && now - this.lastCapture > 120000))) {
      void this.write();
      this.session = null;
    }
    if (!this.session && !input) return;
    if (!this.session) this.begin();
    const time = Date.now() - this.started;
    if (input && ['m', 'c', 'w', 'k', 'a'].includes(payload.type)) this.lastInput = Date.now();
    if (payload.type === 'a') return;
    let event;
    const values = payload.values;
    if (['m', 'c', 'w'].includes(payload.type)) {
      if (!Array.isArray(values) || values.length > 4 || !values.every(Number.isFinite)) return;
      event = [payload.type, time, ...values.map(value => Math.max(-10000, Math.min(10000, value)))];
    } else if (payload.type === 'k') {
      if (!Array.isArray(values) || typeof values[0] !== 'string' || !/^(Key[A-Z]|Digit[0-9]|Arrow\w+|Space|Enter|Escape|Tab|Shift\w*|Control\w*|Alt\w*|Meta\w*|F\d{1,2})$/.test(values[0])) return;
      event = ['k', time, values[0], Boolean(values[1])];
    } else if (payload.type === 'f') event = ['f', time, Boolean(values?.[0])];
    else if (payload.type === 'v') {
      if (!Array.isArray(values) || values.length !== 2 || !values.every(value => Number.isInteger(value) && value > 0 && value <= 32768)) return;
      event = ['v', time, ...values];
    } else if (payload.type === 'e' && typeof payload.name === 'string') {
      const name = payload.name.slice(0, 32);
      const style = clean(payload.style) || {};
      event = ['e', time, name, clean(payload.data), style];
      this.marks.add(name);
      if (typeof style.highlight === 'string') this.highlights.add(style.highlight.slice(0, 32));
      if (name === 'error') this.errors++;
    } else return;
    const eventBytes = Buffer.byteLength(JSON.stringify(event));
    if (eventBytes > 4096) return;
    if (this.eventBytes + this.bytes + eventBytes > MAX_BYTES) await this.write();
    this.events.push(event);
    this.eventBytes += eventBytes;
    if (this.events.length >= 1000 || time - this.segmentStart >= 15000) await this.write();
  }

  async identify(value) {
    const player = typeof value === 'string' ? value.slice(0, 64) : '';
    if (player === (this.metadata.player_id || '')) return this.session;
    await this.write();
    this.metadata.player_id = player;
    if (this.enabled) this.begin();
    return this.session;
  }

  write() {
    if (!this.session || (!this.frames.length && !this.events.length)) return this.pendingWrite;
    const header = {
      session: this.session, seq: this.sequence++, t0: this.segmentStart, t1: Date.now() - this.started,
      frames: this.frames, size: this.size || [960, 540], errors: this.errors,
      marks: [...this.marks], highlights: [...this.highlights],
    };
    if (header.seq === 0) header.meta = {
      ...this.options.metadata, ...this.metadata, session_id: this.session, game_id: this.options.game,
      install_id: this.installId, started_at: new Date(this.started).toISOString(), os: process.platform,
      engine_version: 'Electron ' + process.versions.electron,
    };
    const json = Buffer.from(JSON.stringify(header));
    const events = gzipSync(Buffer.from(JSON.stringify(this.events)));
    const prefix = Buffer.alloc(9); prefix.write('RPLY'); prefix[4] = 1; prefix.writeUInt32LE(json.length, 5);
    const length = Buffer.alloc(4); length.writeUInt32LE(events.length);
    const buffer = Buffer.concat([prefix, json, length, events, ...this.images]);
    const filename = `${this.options.game}_${this.session}_${String(header.seq).padStart(5, '0')}.rply`;
    this.reset();
    if (this.sequence >= 4000) this.begin();
    this.pendingWrite = this.pendingWrite.then(async () => {
      await this.ready;
      const target = path.join(this.directory, filename);
      await fs.writeFile(target + '.tmp', buffer, {mode: 0o600});
      await fs.rename(target + '.tmp', target);
      await this.trim();
    }).catch(error => this.warn(error, 'write'));
    return this.pendingWrite;
  }

  async files() {
    const names = (await fs.readdir(this.directory)).filter(name => /^[a-z0-9_-]+_[a-f0-9]{32}_\d{5}\.rply$/.test(name));
    const files = await Promise.all(names.map(async name => ({name, ...(await fs.stat(path.join(this.directory, name)))})));
    return files.sort((a, b) => a.mtimeMs - b.mtimeMs || a.name.localeCompare(b.name));
  }

  async trim() {
    const files = await this.files();
    let total = files.reduce((sum, file) => sum + file.size, 0);
    for (const file of files) {
      if (total <= 300 * 1024 * 1024) break;
      await fs.unlink(path.join(this.directory, file.name)); total -= file.size;
    }
  }

  async upload() {
    if (this.uploading) return this.uploading;
    this.uploading = (async () => {
      await this.ready;
      await this.pendingWrite;
      for (const file of await this.files()) {
        const match = file.name.match(/^(.+)_([a-f0-9]{32})_(\d{5})\.rply$/);
        const target = path.join(this.directory, file.name);
        let body;
        try { body = await fs.readFile(target); }
        catch (error) { this.warn(error, 'read'); continue; }
        const response = await fetch(this.options.endpoint, {method: 'POST', signal: AbortSignal.timeout(15000),
          headers: {'Content-Type': 'application/octet-stream', 'X-Replay-Game': match[1], 'X-Replay-Session': match[2], 'X-Replay-Sequence': String(Number(match[3]))},
          body});
        if (response.ok || [409, 410].includes(response.status)) await fs.unlink(target);
        else {
          this.warn({code: `HTTP_${response.status}`}, 'upload');
          // Retrying invalid payloads cannot repair them; don't strand later recordings.
          if ([400, 413, 422].includes(response.status)) await fs.unlink(target);
          else break; // Keep data and back off for outages, rate limits and configuration failures.
        }
      }
    })().catch(error => this.warn(error, 'upload')).finally(() => { this.uploading = null; });
    return this.uploading;
  }

  async flush() { await this.write(); await this.upload(); }
  async stop() {
    if (!this.enabled && !this.session) return;
    this.enabled = false; await this.flush(); this.session = null;
  }
  async dispose() {
    recorders.delete(this.contentsId);
    clearInterval(this.retry);
    await this.stop();
  }
}

exports.installReplay = (window, options) => new Recorder(window, options);
