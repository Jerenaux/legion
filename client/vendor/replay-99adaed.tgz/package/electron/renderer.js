// Browser-side encoder/input collector. The sandboxed preload supplies only this bridge.
export function startReplay(bridge, onSession = () => {}, onError = () => {}) {
  if (!bridge) return {event() {}, activity() {}, identify() {}, stop() {}};
  let stopped = false;
  let busy = false;
  let pointerAt = 0;
  let session;
  const removers = [];
  const reported = new Map();
  let activityAt = 0;
  const failed = (error, operation) => {
    const now = Date.now();
    if (now - (reported.get(operation) || 0) < 60000) return;
    reported.set(operation, now);
    const failure = new Error(`Replay ${operation} failed`);
    const code = String(error?.code || error?.name || 'Error');
    if (/^[\w-]{1,40}$/.test(code)) failure.code = code;
    try { onError(failure, operation); } catch { /* Diagnostics must never affect play. */ }
  };
  const report = (promise, operation) => Promise.resolve(promise).catch(error => failed(error, operation));
  const changed = value => { if (value && value !== session) { session = value; onSession(value); } };
  const send = payload => { if (!stopped) void report(Promise.resolve().then(() => bridge.event(payload)), 'event'); };
  const listen = (name, callback) => {
    window.addEventListener(name, callback, true);
    removers.push(() => window.removeEventListener(name, callback, true));
  };
  const point = event => [Math.round(event.clientX / innerWidth * 10000), Math.round(event.clientY / innerHeight * 10000)];
  const privateElement = element => element instanceof Element && Boolean(element.closest('[data-replay-mask], [data-private], input[type="password"], input[autocomplete*="password"]'));
  const editable = element => element instanceof Element && Boolean(element.closest('input, textarea, select, [contenteditable]:not([contenteditable="false"])'));
  listen('pointermove', event => {
    if (performance.now() - pointerAt < 33 || privateElement(event.target)) return;
    pointerAt = performance.now(); send({type: 'm', values: point(event)});
  });
  for (const name of ['pointerdown', 'pointerup']) listen(name, event => {
    if (!privateElement(event.target)) send({type: 'c', values: [...point(event), ([1, 3, 2][event.button] || event.button + 1), name === 'pointerdown' ? 1 : 0]});
  });
  listen('wheel', event => { if (!privateElement(event.target)) send({type: 'w', values: [...point(event), Math.sign(event.deltaY)]}); });
  for (const name of ['keydown', 'keyup']) listen(name, event => {
    if (!event.repeat && !editable(event.target) && !privateElement(event.target)) send({type: 'k', values: [event.code, name === 'keydown']});
  });
  listen('focus', event => { if (event.target === window) send({type: 'f', values: [true]}); });
  listen('blur', event => { if (event.target === window) send({type: 'f', values: [false]}); });
  listen('resize', () => send({type: 'v', values: [innerWidth, innerHeight]}));
  const privateRects = () => [...document.querySelectorAll('[data-replay-mask], [data-private], input[type="password"], input[autocomplete*="password"]')]
    .map(element => element.getBoundingClientRect()).filter(rect => rect.width && rect.height);
  const capture = async () => {
    if (busy || stopped || document.hidden) return;
    busy = true;
    let bitmap;
    try {
      const masks = privateRects().map(rect => [rect.x, rect.y, rect.width, rect.height]);
      const frame = await bridge.capture({width: innerWidth, height: innerHeight, masks});
      if (!frame || stopped) return;
      changed(frame.session);
      bitmap = await createImageBitmap(new Blob([frame.png], {type: 'image/png'}));
      const canvas = new OffscreenCanvas(frame.width, frame.height);
      const context = canvas.getContext('2d');
      context.drawImage(bitmap, 0, 0, frame.width, frame.height);
      // Cover private regions again if their layout changed during native capture.
      context.fillStyle = '#101010';
      for (const rect of privateRects()) context.fillRect(
        rect.x / innerWidth * frame.width - 2, rect.y / innerHeight * frame.height - 2,
        rect.width / innerWidth * frame.width + 4, rect.height / innerHeight * frame.height + 4);
      const blob = await canvas.convertToBlob({type: 'image/webp', quality: 0.5});
      if (!stopped) await bridge.frame({...frame, png: undefined, bytes: new Uint8Array(await blob.arrayBuffer())});
    } catch (error) { failed(error, 'capture'); }
    finally { bitmap?.close(); busy = false; }
  };
  void report(Promise.resolve().then(() => bridge.start()).then(value => { changed(value); return capture(); }), 'start');
  const timer = setInterval(() => { void capture(); }, 500);
  listen('pagehide', () => { void report(Promise.resolve().then(() => bridge.flush()), 'flush'); });
  return {
    event(name, data = {}, style = {}) { send({type: 'e', name, data, style}); },
    activity() {
      if (Date.now() - activityAt < 500) return;
      activityAt = Date.now(); send({type: 'a'});
    },
    identify(player) { void report(Promise.resolve().then(() => bridge.identify(player || '')).then(changed), 'identify'); },
    async stop() {
      stopped = true; clearInterval(timer); for (const remove of removers) remove();
      await report(Promise.resolve().then(() => bridge.stop()), 'stop');
    },
  };
}
