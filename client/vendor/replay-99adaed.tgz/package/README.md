# Replay libraries, backend and dashboard

Shared Godot and Electron recorders, plus their game-agnostic backend and dashboard. Deployed in Firebase project `games-analytics-jr` (europe-west1).

**Integrating a new game? Start with [the integration guide](docs/integration.md).**
It contains the complete agent handoff: pinned installation for Godot/Electron,
CI, store-build gates, verified user identity, privacy, lifecycle, backend registration,
testing and upgrades. Repository instructions are in [AGENTS.md](AGENTS.md).

- `replayIngest` (public, write-only): accepts RPLY segments for games listed in
  `REPLAY_GAMES`, validates and stores them immutably in
  `gs://games-analytics-jr-replays/{game}/{session}/{seq}.rply`, and updates the
  Firestore summary `replaySessions/{session}` (metadata, duration, frames, size,
  errors, event marks, country). Country comes from the uploader's IP via DB-IP's
  free country database (CC BY 4.0, https://db-ip.com); the IP is not stored.
- `replayApi` (private): session list, session, segment bytes and deletion for the
  dashboard. Requires a Firebase ID token for an email in `REPLAY_ADMINS`. Deleting
  writes a tombstone (`replayTombstones/{session}`), so segments still waiting in a
  player's outbox are refused with 410 instead of recreating the session.
- `dashboard/`: static site at https://games-replay-jr.web.app, `/api/**` rewritten
  to `replayApi`. It can also play `.rply` files from disk (drop them on the page),
  including when served locally without a backend.

The dashboard refresh button reloads the newest sessions. Green unread pips clear once a
replay frame loads; watched status is saved in this browser, without cross-device sync.

Retention: the bucket deletes objects after 90 days; a Firestore TTL policy on
`expireAt` removes session documents and tombstones. Functions run as the dedicated
`replay-runtime` service account (bucket object admin + Firestore user).

## Deploy

```sh
cd ~/Code/replay
npm ci --prefix functions
npm --prefix functions run build-geo # compiles the country database
firebase deploy --only functions:replay,hosting:games-replay-jr
```

The `replay` codebase never touches the analytics functions. Configuration is in
`functions/.env` (bucket, games, admins, retention).

## Dashboard sign-in (one-time)

In the Firebase console for `games-analytics-jr`: Authentication > Get started >
Sign-in method > enable **Google**; then Authentication > Settings > Authorized
domains > add `games-replay-jr.web.app`.

## Godot library

The canonical Godot addon lives in [`godot/addons/replay`](godot/addons/replay/README.md), alongside `electron/`. Game repositories commit a pinned copy, not a link to another checkout. Keep game-specific settings, markers and recording eligibility in each game.

To package an addon version, update `godot/addons/replay/plugin.cfg`, commit the source, then run:

```sh
python3 godot/package.py
```

This creates `dist/replay-godot-<version>.zip`, containing `addons/replay/` and an `upstream.json` with the exact source commit and file checksums. Packaging rejects uncommitted addon changes. The archive is deterministic and can be attached to a GitHub release; no package registry or separate hosting is required. Godot versions are independent of the Electron npm version.

To install or upgrade, extract the package into a game repository after removing its old `addons/replay/`, run `python3 addons/replay/verify.py`, and commit the resulting directory. Enable the plugin/autoload as described in the addon README. CI runs that verifier and the normal Godot import/export, without fetching this repository or using private-repository credentials. Runtime recordings still upload to the shared backend using the game's own allowlisted ID.

## Electron library

The dependency-free `@jerenaux/replay` package in this repository records the composed
Electron window (including DOM overlays and WebGL) in the same RPLY v1 format as Godot.
Install a pinned npm tarball and commit it with the game's lockfile so CI needs no
private repository access. See the [Electron integration guide](docs/integration.md#electron--phaser-installation)
for main/preload/renderer examples and shutdown requirements.

The host application owns recording eligibility. Skip main recorder installation
and preload exposure on excluded builds, since main installation can retry older
pending uploads even before renderer recording starts. Establish the verified
platform/account identity before the first `startReplay()` call; cached auth
restoration can otherwise create a short recording under the wrong user. One
controller survives scene changes; a real account change uses `identify()` to start
a separate session. The main process verifies the window, main frame and trusted
URL on every IPC request.

Capture is limited to 2 fps and 960 pixels wide, encoded to WebP at quality 0.5.
Identical thumbnails are skipped. Segments flush every 15 seconds or before 3.5 MB;
atomic disk writes precede uploads. The outbox retries after failures and on relaunch,
and drops its oldest files above 300 MB. A crash can lose the current in-memory segment.
Thirty minutes without input suspends a session; input resumes in a new session.
Capture gaps above two minutes split sessions as well.

Password inputs and elements with `data-replay-mask` or `data-private` are blanked in
frames. Text-field typing is never recorded as key events. Other visible text remains
visible, so mark sensitive UI before displaying it. Explicit event data is bounded and
scrubs credential fields and URL credentials/query/fragment. No network traffic or
console text is collected. Audio and browser-only page recording are not supported.
The recorder captures the app's page, never the desktop or other apps.

`npm test` runs dashboard checks. To include the real Electron capture/outbox/HTTP/
privacy compatibility check, set `REPLAY_ELECTRON` to an Electron executable before
running it. The integration check uses an isolated profile and loopback uploads only.

### New replay Telegram alerts

`replayNotify` runs when a new `replaySessions` document is created and sends Jerome a game name, platform/channel and private dashboard link. Later segments do not send additional alerts. The bot token is bound only to this function through Secret Manager (`REPLAY_TELEGRAM_BOT_TOKEN`); the private recipient is configured with `REPLAY_TELEGRAM_CHAT_ID`.

Firestore event retries recover from Telegram errors. A transaction lease prevents concurrent deliveries, and `telegramNotifiedAt` skips already completed alerts. As with any external message API without an idempotency key, a crash after Telegram accepts the message but before the receipt is saved can cause a duplicate. Existing recordings are not backfilled.

Run the notification integration check against a disposable Firestore emulator after installing backend dependencies:

```sh
npm --prefix functions ci
firebase emulators:exec --only firestore --project demo-replay 'node --test tests/notifications.test.cjs'
```

The custom runtime account needs `roles/eventarc.eventReceiver` on the project and `roles/run.invoker` on the `replaynotify` service. After the first deployment, grant the service-scoped invocation role:

```sh
gcloud run services add-iam-policy-binding replaynotify --project games-analytics-jr --region europe-west1 \
  --member serviceAccount:replay-runtime@games-analytics-jr.iam.gserviceaccount.com --role roles/run.invoker
```

The list shows channel and OS icons with accessible names/tooltips. Total storage comes from a server-side Firestore sum across all session documents, independent of filters and pagination; refresh updates it, and successful deletions subtract the removed sessions.

Player identity is stored in `meta.player_id`. Electron games call `sessionReplay.identify(userId)`; a changed identity closes the current segment and starts a separate session, so recordings never combine two signed-in players. Both recorders also provide a persistent `install_id` for installations without account IDs. The current dashboard can search metadata IDs and show them in session details; it does not yet group rows by player.

The User column displays `meta.player_id`, or a shared display alias. Clicking it opens a rename dialog; saving writes to the admin-only `replayUserAliases` collection, keyed by a hash of game and original user ID. All sessions for that user/game display the alias, including future and older pages. Clearing the name restores the original ID. Alias changes never modify replay metadata, game accounts or recordings; search matches both aliases and original IDs.
